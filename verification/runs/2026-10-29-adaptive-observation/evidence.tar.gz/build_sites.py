from pathlib import Path
import hashlib, json, os, shutil, signal, subprocess, sys, time
sys.dont_write_bytecode = True
omega = Path('/Users/taaliman/projects/oldman/synarcai/omega')
sys.path.insert(0, str(omega / 'scripts/measure'))
from validation_resources import ResourceContract, darwin_memory_snapshot

root = Path(__file__).resolve().parent
name = sys.argv[1]
site = {'foundations': Path('/Users/taaliman/projects/oldman/math-foundations'),
        'holon': Path('/Users/taaliman/projects/oldman/uhm-theory/holon/website')}[name]
out = root / (name + '-build')
out.mkdir(exist_ok=False)
record = {'site': str(site), 'status': 'registered', 'heap_mib': 8192,
          'owned_tree_limit_bytes': 25_000_000_000, 'reserve_gib': 8}
def save():
    temp = out / 'receipt.tmp'
    temp.write_text(json.dumps(record, indent=2) + '\n')
    temp.replace(out / 'receipt.json')
def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard',
                                    '--', '*.md', '*.mdx', '*.ts', '*.tsx', '*.js', '*.json', '*.cjs', '*.mjs'],
                                   cwd=site, text=True).splitlines()
    return {p: hashlib.sha256((site/p).read_bytes()).hexdigest() for p in sorted(set(paths))
            if (site/p).is_file()}
def resource():
    rows = [tuple(map(int, line.split())) for line in subprocess.check_output(
        ['ps', '-axo', 'pid=,ppid=,rss='], text=True).splitlines()]
    owned = {os.getpid()}
    while True:
        more = {p for p, parent, _ in rows if parent in owned}
        if more <= owned: break
        owned |= more
    sample = dict(at=time.time(), **darwin_memory_snapshot(subprocess.check_output(['vm_stat'], text=True)),
                  pressure_dispatch_level=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True)),
                  disk_free_gib=shutil.disk_usage(out).free/2**30,
                  owned_rss_bytes=sum(r*1024 for p,_,r in rows if p in owned))
    with (out/'resources.jsonl').open('a') as f: f.write(json.dumps(sample)+'\n')
    return sample
contract = ResourceContract(25_000_000_000)
initial = resource()
record['initial_resource'] = initial
env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=8192', SLOT_PRIO='1', CI='true')
slot, child = None, None
try:
    failure = contract.failure(initial, initial['swapouts'], admission=True)
    if failure: raise RuntimeError(failure)
    slot = subprocess.check_output(['zsh','/tmp/heavy_slot.sh','acquire','idea-v66-'+name,'build'],env=env,text=True).strip()
    failure = contract.failure(resource(), initial['swapouts'], admission=True)
    if failure: raise RuntimeError(failure)
    sources = snapshot()
    record.update(status='running', sources=sources, slot=slot, started=time.time())
    cmd = ['node','node_modules/@docusaurus/core/bin/docusaurus.mjs','build']
    record['command'] = cmd
    save()
    with (out/'build.log').open('xb') as log:
        child = subprocess.Popen(cmd,cwd=site,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        record['pid'] = child.pid
        while child.poll() is None:
            sample = resource()
            record['peak_owned_rss_bytes'] = max(record.get('peak_owned_rss_bytes',0),sample['owned_rss_bytes'])
            record['latest_resource'] = sample
            save()
            failure = contract.failure(sample,initial['swapouts'],admission=False)
            if failure: raise RuntimeError(failure)
            if time.time()-record['started']>2400: raise TimeoutError(name)
            time.sleep(2)
    record['returncode'] = child.returncode
    if snapshot()!=sources: raise RuntimeError('site sources changed during build')
    record['status'] = 'passed' if child.returncode == 0 else 'failed'
finally:
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try: child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL); child.wait()
        record['status']='interrupted'
    if slot:
        subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,'build'],check=True,capture_output=True)
    record['finished'] = time.time()
    save()
print(json.dumps({'status':record['status'],'receipt':str(out/'receipt.json')}))
sys.exit(0 if record['status']=='passed' else 1)
